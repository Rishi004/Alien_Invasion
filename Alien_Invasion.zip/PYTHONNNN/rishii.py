import pygame

print(dir(pygame))